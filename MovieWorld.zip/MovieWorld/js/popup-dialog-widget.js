/**
 * Popup-Dialog Widget
*/

$( document ).ready( function() {

    initPopupDialog();
                    				
} );

function initPopupDialog()
{			
	$( '#add-movie-dialog' ).dialog({
		title: 'Add Movie',
		autoOpen: false,
		draggable: false,
		resizable: false,
		width: 'auto',
		buttons : [
			{
				text: 'OK',
				click: function ()
				{					
					$.ajax({
						type: "POST",
						url: "ajax/process-movie.php",
						data: {
							'action': 'add',
							'popupDialogData': $( '#popup-dialog' ).serialize()
						},
						dataType: 'json',
						cache: false,
						success: function()
						{
							if( data.success ) {
								$( this ).dialog( "close" );
							}
						}
					});
				}
			},
			{
				text: 'Cancel',
				click: function () {
					$( this ).dialog( "close" );
				}
			}
		]
    });
}

function openPopupDialog()
{
	// Movie Form
	var html = "";
	html += "<div>";
	html += "<form id=\"popup-dialog\">";
	html += "<input type=\"text\" name=\"name\" placeholder=\"Name\"/>";
	html += "<input type=\"text\" name=\"description\" placeholder=\"Description\"/>";
	html += "</form>";
	html += "</div>";
		
	$( '#add-movie-dialog' ).html( html ).dialog( 'open' );
}
